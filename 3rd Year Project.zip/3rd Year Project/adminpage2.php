<!DOCTYPE html>

<html>
<head>
	<title>WELCOME ADMIN</title>
</head>
<body>

<link rel="stylesheet" type="text/css" href="admincs.css">
<center>
<img src="logo.jpg" ><b>
<br><div class="pp" >
<div class="pqr">
    <h1  class="glow" 
    style="font-family:'Allura', cursive;
               text-align: center;
               margin-top: -1%;
               font-size: 50px;
               color: #ff0000; " >Heart of Humanity</h1></div>
<h1 style="color: blue;margin-top: -2%;">Welcome Admin</h1>
<a href="volunteer.php"><button class="button">Show Volunteers List</button></a><br><br>
<a href="applicants.php"><button class="button">Volunteers Applicants</button></a><br><br>
<a href="verificationpage.php"><button class="button">Applicants Verification</button></a><br><br>
<a href="showcomplaints.php"><button class="button">Complaints</button></a><br><br>
<a href="addeventspage.php"><button class="button">Add More Events</button></a><br><br>
<br><br>
<a href="proj.html"><button class="button">LOG OUT</button></a><br><br>
</div>
</center>



</body>
</html>